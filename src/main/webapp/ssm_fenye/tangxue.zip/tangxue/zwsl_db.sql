/*
Navicat MySQL Data Transfer

Source Server         : local_mysql
Source Server Version : 50723
Source Host           : localhost:3306
Source Database       : zwsl_db

Target Server Type    : MYSQL
Target Server Version : 50723
File Encoding         : 65001

Date: 2019-04-11 14:43:50
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for t_category
-- ----------------------------
DROP TABLE IF EXISTS `t_category`;
CREATE TABLE `t_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `cname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_category
-- ----------------------------
INSERT INTO `t_category` VALUES ('1', '卡类证件');
INSERT INTO `t_category` VALUES ('2', '随身物品');
INSERT INTO `t_category` VALUES ('3', '电子数码');
INSERT INTO `t_category` VALUES ('4', '书籍资料');
INSERT INTO `t_category` VALUES ('5', '衣物饰品');
INSERT INTO `t_category` VALUES ('6', '其他物品');

-- ----------------------------
-- Table structure for t_claimuser
-- ----------------------------
DROP TABLE IF EXISTS `t_claimuser`;
CREATE TABLE `t_claimuser` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `tel` varchar(255) DEFAULT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_claimuser
-- ----------------------------
INSERT INTO `t_claimuser` VALUES ('2', '24689@qq.com', '16748940433', '吱吱');
INSERT INTO `t_claimuser` VALUES ('4', '876896@qq.com', '15128899888', '马斯');
INSERT INTO `t_claimuser` VALUES ('5', '89666@qq.com', '13999877899', '玛丽');
INSERT INTO `t_claimuser` VALUES ('6', 'admin@qq.com', '13566789943', '张三');
INSERT INTO `t_claimuser` VALUES ('7', 'test@qq.com', '15122456787', '李四');
INSERT INTO `t_claimuser` VALUES ('8', 'test@qq.com', '18966364532', '小小');
INSERT INTO `t_claimuser` VALUES ('9', 'hellokitty@qq.com', '13112388888', 'hellokitty');
INSERT INTO `t_claimuser` VALUES ('10', '1039909390@qq.com', '15128899888', 'kajsx');
INSERT INTO `t_claimuser` VALUES ('11', 'tangtang@qq.com', '15128899888', 'admin');

-- ----------------------------
-- Table structure for t_goods
-- ----------------------------
DROP TABLE IF EXISTS `t_goods`;
CREATE TABLE `t_goods` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `address` varchar(255) DEFAULT NULL,
  `crearetime` datetime DEFAULT NULL,
  `happentime` datetime DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `mobile` varchar(255) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `qq` varchar(255) DEFAULT NULL,
  `remark` varchar(255) DEFAULT NULL,
  `result` varchar(255) DEFAULT NULL,
  `state` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `typename` varchar(255) DEFAULT NULL,
  `cid` int(11) DEFAULT NULL,
  `claimuid` int(11) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9E8BE3ABB4525B3D` (`uid`),
  KEY `FK9E8BE3AB10FBE6D9` (`claimuid`),
  KEY `FK9E8BE3AB6E2F87DE` (`cid`),
  CONSTRAINT `FK9E8BE3AB10FBE6D9` FOREIGN KEY (`claimuid`) REFERENCES `t_claimuser` (`id`),
  CONSTRAINT `FK9E8BE3AB6E2F87DE` FOREIGN KEY (`cid`) REFERENCES `t_category` (`id`),
  CONSTRAINT `FK9E8BE3ABB4525B3D` FOREIGN KEY (`uid`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_goods
-- ----------------------------
INSERT INTO `t_goods` VALUES ('3', '图书馆', '2017-09-14 21:18:58', '2017-09-14 00:00:00', '图书馆丢失一部苹果7手机，白色，无手机壳，麻烦拾到第一时间和我去的联系，必有重谢', '13833388998', '苹果7手机', '8088188', '白色', null, '0', '图书馆丢失一部苹果7手机', 'lost', '3', null, '2');
INSERT INTO `t_goods` VALUES ('4', '宿舍', '2017-09-14 21:24:25', '2017-09-12 00:00:00', '宿舍门口捡到高数课本一份', '13938819911', '高数书', '89881888', '无', '已认证失主，特此声明', '1', '宿舍门口捡到高数课本一份', 'find', '4', '4', '2');
INSERT INTO `t_goods` VALUES ('5', '宿舍门口', '2017-09-14 21:29:41', '2017-09-13 00:00:00', '拾到金色钥匙一把，王力门业的', '13928839887', '钥匙', '8829988', '金色', '已找到失主谢谢关注', '1', '拾到金色钥匙一把', 'find', '6', '5', '2');
INSERT INTO `t_goods` VALUES ('6', '食堂里面', '2017-09-14 14:37:21', '2017-09-05 00:00:00', '寻找钥匙一串，一大一小。', '18251986666', '钥匙', '1903879333', '重要的钥匙，希望拾到的好心人联系我', null, '0', '寻找钥匙', 'lost', '6', null, '1');
INSERT INTO `t_goods` VALUES ('7', '图书馆二楼', '2017-09-14 14:41:34', '2017-09-12 00:00:00', '图书馆二楼捡到一本编程书', '18251987777', '编程书', '1903879222', '无', null, '0', '捡到一本书', 'find', '4', null, '1');
INSERT INTO `t_goods` VALUES ('10', '音乐厅', '2017-09-14 23:33:40', '2017-09-11 00:00:00', '在音乐厅捡到粉色钱包一个，请失主看到后速与我联系！', '13567899876', '钱包', '', '钱包', null, '0', '捡到钱包一个', 'find', '6', null, '1');
INSERT INTO `t_goods` VALUES ('11', '北食堂', '2017-09-14 23:37:59', '2017-09-13 00:00:00', '在北食堂捡到耳机一个，失主速与我联系。', '13151695876', '耳机', '1903879222', '白色耳机', null, '0', '捡到耳机', 'find', '3', null, '1');
INSERT INTO `t_goods` VALUES ('12', '服务区一楼花甲店', '2017-09-17 19:30:46', '2017-09-03 00:00:00', '白色文件夹，里面有复习资料，非常重要！', '18251985599', '文件夹', '', '重要', null, '1', '寻找文件夹', 'lost', '4', '7', '1');
INSERT INTO `t_goods` VALUES ('13', '图书馆', '2017-09-27 23:06:38', '2017-09-26 00:00:00', '粉色钱包，丢失地点为图书馆一楼，内有饭卡和现金若干，希望好心人捡到后联系我，万分感谢！', '13523456789', '钱包', '190596721', '粉色钱包', null, '0', '寻找钱包', 'lost', '6', null, '1');
INSERT INTO `t_goods` VALUES ('14', '图书馆二楼电脑室', '2017-09-30 22:59:15', '2017-09-27 00:00:00', '本人在图书馆二楼电脑室丢失银色U盘一个，内有重要资料，希望哪位同学看到能归还给我，十分感谢！', '13899763456', 'U盘', '', '银色', null, '0', '寻找U盘', 'lost', '3', null, '1');
INSERT INTO `t_goods` VALUES ('15', '服务区三楼', '2017-09-30 23:07:32', '2017-09-30 00:00:00', '捡到一张身份证，名字是赵丽丽，请失主与我联系。', '13923456578', '身份证', '', '身份证', null, '1', '捡到一张身份证', 'find', '1', '8', '1');
INSERT INTO `t_goods` VALUES ('16', '教学楼', '2017-09-03 20:13:14', '2017-09-03 00:00:00', '本人丢失借书证一枚，捡到的同学请于我联系。十分感谢', '13512512345', '图书借阅证', '123123', '', null, '0', '急寻借书证', 'lost', '1', null, '8');
INSERT INTO `t_goods` VALUES ('17', '图书馆', '2017-09-03 20:23:46', '2017-09-03 00:00:00', '在图书馆看书时候丢失的。', '18112312345', '红米', '123123', '5.5寸', '已经领到啦。', '1', '丢失一部手机，急寻', 'lost', '3', '9', '9');
INSERT INTO `t_goods` VALUES ('18', '食堂', '2017-09-03 20:22:15', '2017-09-03 00:00:00', 'Java编程思想，英文版的。', '18612311111', 'Java编程思想', '12312312', '', null, '0', '捡到一本Java编程思想', 'find', '4', null, '9');
INSERT INTO `t_goods` VALUES ('28', '哈哈哈', '2019-04-11 11:24:43', '2019-04-11 00:00:00', '哈哈哈1', '13313131313', '哈哈哈1', '121212', '哈哈哈1', null, '1', '哈哈哈1', 'lost', '6', '11', '1');
INSERT INTO `t_goods` VALUES ('32', '哈哈哈', '2019-04-11 14:24:56', '2019-04-11 00:00:00', 'qwq请问', '13313131313', '高数书', '121212', '哈哈哈1', null, '0', '图书', 'lost', '4', null, '1');

-- ----------------------------
-- Table structure for t_reply
-- ----------------------------
DROP TABLE IF EXISTS `t_reply`;
CREATE TABLE `t_reply` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(255) DEFAULT NULL,
  `createtime` datetime DEFAULT NULL,
  `gid` int(11) NOT NULL,
  `uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FK9F225F3FB4525B3D` (`uid`),
  CONSTRAINT `FK9F225F3FB4525B3D` FOREIGN KEY (`uid`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_reply
-- ----------------------------
INSERT INTO `t_reply` VALUES ('1', '补充一下 图书名字写着 张三', '2017-09-14 21:21:19', '4', '2');
INSERT INTO `t_reply` VALUES ('2', '有捡到的的同学麻烦尽快和我联系，重金酬谢', '2017-09-14 21:28:25', '3', '2');
INSERT INTO `t_reply` VALUES ('4', '捡到的同学尽快与我联系，谢谢了。', '2017-09-30 23:00:02', '14', '1');
INSERT INTO `t_reply` VALUES ('5', '我没捡到。。', '2017-09-03 20:20:15', '16', '9');
INSERT INTO `t_reply` VALUES ('6', '1111', '2018-05-18 09:20:39', '14', '1');
INSERT INTO `t_reply` VALUES ('7', 'qwqwqw', '2019-04-09 13:31:27', '22', '11');

-- ----------------------------
-- Table structure for t_thanksletter
-- ----------------------------
DROP TABLE IF EXISTS `t_thanksletter`;
CREATE TABLE `t_thanksletter` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `crearetime` datetime DEFAULT NULL,
  `info` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `uid` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `FKD98DA65AB4525B3D` (`uid`),
  CONSTRAINT `FKD98DA65AB4525B3D` FOREIGN KEY (`uid`) REFERENCES `t_user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_thanksletter
-- ----------------------------
INSERT INTO `t_thanksletter` VALUES ('1', '2017-09-14 21:11:59', '非常感谢张同学拾金不昧的精神', '非常感谢张同学拾金不昧的精神', '2');
INSERT INTO `t_thanksletter` VALUES ('2', '2017-09-14 21:27:53', '非常感谢李同学无私奉献，拾金不昧的精神', '非常感谢李同学无私奉献，拾金不昧的精神', '2');
INSERT INTO `t_thanksletter` VALUES ('4', '2017-09-14 23:35:09', '感谢赵旭同学将捡到我的饭卡还给了我。', '感谢赵旭同学拾金不昧，乐于助人', '1');
INSERT INTO `t_thanksletter` VALUES ('5', '2017-09-30 23:03:17', '刘同学捡到我的钱包并归还于我，太感谢啦！', '感谢刘同学拾金不昧', '1');
INSERT INTO `t_thanksletter` VALUES ('6', '2017-09-03 20:22:45', '感谢党和人民。', '感谢感谢', '9');
INSERT INTO `t_thanksletter` VALUES ('7', '2019-04-08 15:37:11', 'thaks', '图书', '11');
INSERT INTO `t_thanksletter` VALUES ('19', '2019-04-08 20:21:03', 'qqq', '图书', '11');
INSERT INTO `t_thanksletter` VALUES ('20', '2019-04-08 20:21:11', 'q', 'qw', '11');
INSERT INTO `t_thanksletter` VALUES ('21', '2019-04-08 20:21:25', 'qq', '图书', '11');
INSERT INTO `t_thanksletter` VALUES ('22', '2019-04-08 20:21:32', 'qq', 'qq', '11');
INSERT INTO `t_thanksletter` VALUES ('23', '2019-04-08 20:21:37', 'qq', 'qq', '11');

-- ----------------------------
-- Table structure for t_user
-- ----------------------------
DROP TABLE IF EXISTS `t_user`;
CREATE TABLE `t_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `createtime` datetime DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `role` int(11) NOT NULL,
  `userlock` int(11) NOT NULL,
  `username` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_user
-- ----------------------------
INSERT INTO `t_user` VALUES ('1', '2017-09-10 22:01:22', 'admin@qq.com', 'tang', '1', '0', '管理员');
INSERT INTO `t_user` VALUES ('2', '2017-09-14 21:02:57', 'test@qq.com', '111111', '0', '0', '普通用户');
INSERT INTO `t_user` VALUES ('3', '2017-09-14 21:02:57', 'admin', 'admin', '1', '0', 'admin');
INSERT INTO `t_user` VALUES ('4', '2017-09-16 13:15:56', '1903879311@qq.com', '123456', '0', '0', '失物招领');
INSERT INTO `t_user` VALUES ('5', '2017-09-30 22:56:41', '16354211@qq.com', '123456', '0', '0', '李小龙');
INSERT INTO `t_user` VALUES ('6', '2017-09-03 01:13:48', '1168792@qq.com', '030613', '0', '0', '盛青青');
INSERT INTO `t_user` VALUES ('7', '2017-09-03 15:28:22', '188726665@qq.com', '123456', '0', '0', '张明');
INSERT INTO `t_user` VALUES ('8', '2017-09-03 20:07:20', 'hellokitty@qq.com', '123456', '0', '0', 'hellokitty');
INSERT INTO `t_user` VALUES ('9', '2017-09-03 20:19:50', 'wakaka@qq.com', '123456', '0', '0', '哇咔咔');
INSERT INTO `t_user` VALUES ('10', '2018-05-18 09:21:35', '516027583@qq.com', 'synitalent', '0', '0', 'demo');
INSERT INTO `t_user` VALUES ('11', '2019-04-08 10:09:31', 'tangtang@qq.com', 'tangtang', '0', '0', 'tangxue');
