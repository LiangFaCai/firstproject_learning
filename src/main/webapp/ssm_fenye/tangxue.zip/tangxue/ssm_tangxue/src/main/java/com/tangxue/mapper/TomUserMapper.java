package com.tangxue.mapper;

import java.util.List;
import java.util.Map;

import com.tangxue.dto.TomGoodsDto;
import com.tangxue.entity.TomGoods;
import com.tangxue.entity.TomUser;

public interface TomUserMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TomUser record);

    int insertSelective(TomUser record);

    TomUser selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TomUser record);

    int updateByPrimaryKey(TomUser record);
    /**
     * 获取用户列表
     * @return
     */
	List getUserList();
	/**
	 * 获取用户对象
	 * @return
	 */
	TomUser selectBean();
	/**
	 * 登陆查询
	 * @param paramMap
	 * @return
	 */
	TomUser selectUserByCondition(Map<String, Object> paramMap);

	/**
	 * 判断用户是否已被注册
	 * @param paramMap
	 * @return
	 */
	TomUser selectByCondition(Map<String, Object> paramMap);

	/**
	 *根据原来的密码查询对象
	 * @param paramMap
	 * @return
	 */
	TomUser selectByOldPwdAndUsername(Map<String, Object> paramMap);

	/**
	 * 管理端登陆
	 * @param paramMap
	 * @return
	 */
	TomUser selectManagerUser(Map<String, Object> paramMap);

	/**
	 * 管理端密码修改获取对象
	 * @param paramMap
	 * @return
	 */
	TomUser selectUserByOldPwdAndEmail(Map<String, Object> paramMap);
	/**
	 * 管理端用户列表
	 * @param paramMap
	 * @return
	 */
	List<TomUser> selectManagerUserList(Map<String, Object> paramMap);
	/**
	 * 判断用户是否已经存在
	 * @param paramMap
	 * @return
	 */
	TomUser selectUserByConditions(Map<String, Object> paramMap);
}