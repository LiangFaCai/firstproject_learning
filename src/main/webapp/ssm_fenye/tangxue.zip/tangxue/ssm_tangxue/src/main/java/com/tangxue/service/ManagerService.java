package com.tangxue.service;

import java.util.List;
import java.util.Map;

import com.tangxue.entity.TomGoods;
import com.tangxue.entity.TomReply;
import com.tangxue.entity.TomThanksLetter;
import com.tangxue.entity.TomUser;

public interface ManagerService {

	TomUser selectManagerUser(Map<String, Object> paramMap);

	TomUser selectOldUser(Map<String, Object> paramMap);

	void updateUserPwd(TomUser bean);

	List<TomUser> managerUserList(Map<String, Object> paramMap);

	TomUser selectUserByConditions(Map<String, Object> paramMap);

	void insertManagerUser(TomUser bean);

	void updateManagerUser(TomUser bean);

	TomUser selectManagerUserById(int id);

	List<TomGoods> selectUserGoodsById(Map<String, Object> paramMap);

	void deleteUserGoods(TomGoods tomGoods);

	List<TomReply> selectUserReplyList(Map<String, Object> paramMap);

	void deleteUserReply(TomReply tomReply);

	List<TomThanksLetter> selectThanksList(Map<String, Object> paramMap);

	void deleteUserThanks(TomThanksLetter tomThanksLetter);

	void deleteUserById(int id);

}
