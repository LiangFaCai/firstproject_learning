package com.tangxue.service.impl;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.tangxue.entity.TomGoods;
import com.tangxue.entity.TomUser;
import com.tangxue.mapper.TomGoodsMapper;
import com.tangxue.mapper.TomUserMapper;
import com.tangxue.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private TomUserMapper tomUserMapper;
	@Autowired
	private TomGoodsMapper tomGoodsMapper;
	

	@Override
	public List getUserList() {
	
		return tomUserMapper.getUserList();
	}

	@Override
	public List<TomGoods> selectBeanLostList() {
	
		return tomGoodsMapper.getUserLostList();
	}

	@Override
	public List<TomGoods> selectBeanFindList() {
	
		return tomGoodsMapper.getUserFindList();
	}

	/**
	 * 登陆查询是否登陆
	 */
	@Override
	public TomUser selectUser(String email, String password) {
		
		Map<String,Object> paramMap = new HashMap<String,Object>();
		paramMap.put("email", email);
		paramMap.put("password", password);
		return tomUserMapper.selectUserByCondition(paramMap);
	}

	/**
	 * 判断用户是否已经存在被注册
	 */
	@Override
	public TomUser selectByCondition(Map<String, Object> paramMap) {
		
		return tomUserMapper.selectByCondition(paramMap);
	}

	//添加注册用户
	@Override
	public void inserTomUser(TomUser user) {
	
		tomUserMapper.insert(user);
	}

	/**
	 * 根据原来的密码查询对象
	 */
	@Override
	public TomUser selectByOldPwdAndUsername(Map<String, Object> paramMap) {
		
		return tomUserMapper.selectByOldPwdAndUsername(paramMap);
	}

	//更新对象
	@Override
	public void updateUser(TomUser bean) {
		tomUserMapper.updateByPrimaryKey(bean);
	}

	
	
	
	
	
	
	
}
