package com.tangxue.mapper;

import java.util.List;
import java.util.Map;

import com.tangxue.dto.TomGoodsDto;
import com.tangxue.entity.TomGoods;

public interface TomGoodsMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TomGoods record);

    int insertSelective(TomGoods record);

    TomGoods selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TomGoods record);

    int updateByPrimaryKey(TomGoods record);
    
    /**
	 * 获取丢失列表
	 * @return
	 */
	List<TomGoods> getUserLostList();
	/**
	 * 获取招领列表
	 * @return
	 */
	List<TomGoods> getUserFindList();
	
	/**
	 * 浏览寻物贴
	 * @return
	 */
	List<TomGoodsDto> getBrowsePublishLostList();

	/**
	 * 查看招领贴
	 * @return
	 */
	List<TomGoodsDto> getBrowsePublishFindList();
	/**
	 * 给成功案例
	 * @return
	 */
	List<TomGoodsDto> getSucessEventList();
	/**
	 * 获取物品信息
	 * @param paramMap
	 * @return
	 */
	TomGoodsDto selectGoodsInfoById(Map<String, Object> paramMap);
	/**
	 * 全局搜索
	 * @param paramMap
	 * @return
	 */
	List<TomGoodsDto> globalSearchList(Map<String, Object> paramMap);

	/**
	 * 获取用户物品
	 * @param paramMap
	 * @return
	 */
	List<TomGoods> selectUserGoodsById(Map<String, Object> paramMap);

	/**
	 * 删除用户物品
	 * @param hashMap
	 */
	void deleteUserGoods(Map<String, Object> hashMap);
}