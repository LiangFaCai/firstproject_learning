package com.tangxue.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tangxue.dto.TomThanksLetterDto;
import com.tangxue.entity.TomThanksLetter;
import com.tangxue.mapper.TomThanksLetterMapper;
import com.tangxue.service.ThanksService;


@Service
public class ThanksServiceImpl implements ThanksService{

	@Autowired
	private TomThanksLetterMapper thanksLetterMapper;

	/**
	 * 提交感谢信
	 */
	@Override
	public void insertThanksLetter(TomThanksLetter thanks) {
		
		thanksLetterMapper.insert(thanks);
	}

	//查看总条数
	@Override
	public long selectThaknksCount() {
		
		return thanksLetterMapper.selectThaknksCount();
	}

	@Override
	public List<TomThanksLetterDto> selectThanksLetterList() {
		
		return thanksLetterMapper.selectThanksLetterList();
	}
	
	/**
	 * 感谢信详情
	 */
	@Override
	public TomThanksLetterDto selectThanksLetterInfo(String id) {
		Map<Object,Object> hashMap = new HashMap<>();
		hashMap.put("id", id);
		return thanksLetterMapper.selectThanksLetterInfo(hashMap);
	}

	/**
	 * 管理端感谢信删除
	 */
	@Override
	public void managerThanksDelete(int id) {
		thanksLetterMapper.deleteByPrimaryKey(id);
	}
	
	
}
