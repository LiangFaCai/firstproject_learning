package com.tangxue.mapper;

import java.util.Map;

import com.tangxue.entity.TomClaimuser;

public interface TomClaimuserMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TomClaimuser record);

    int insertSelective(TomClaimuser record);

    TomClaimuser selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TomClaimuser record);

    int updateByPrimaryKey(TomClaimuser record);
    /**
     * 捡到者
     * @param paramMap
     * @return
     */
	TomClaimuser selectGoodsClaimuserByGid(Map<String, Object> paramMap);
	/**
	 * 获取领取者信息
	 * @param hashMap
	 * @return
	 */
	TomClaimuser selectClaimUserByCondition(Map<Object, Object> hashMap);
}