package com.tangxue.mapper;

import java.util.List;
import java.util.Map;

import com.tangxue.dto.TomThanksLetterDto;
import com.tangxue.entity.TomThanksLetter;

public interface TomThanksLetterMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TomThanksLetter record);

    int insertSelective(TomThanksLetter record);

    TomThanksLetter selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TomThanksLetter record);

    int updateByPrimaryKey(TomThanksLetter record);
    /**
     * 获取数量
     * @return
     */
	long selectThaknksCount();
	/**
	 * 获取列表
	 * @return
	 */
	List<TomThanksLetterDto> selectThanksLetterList();
	/**
	 * 根据用户id获取感谢信列表
	 * @param paramMap
	 * @return
	 */
	List<TomThanksLetter> selectThanksList(Map<String, Object> paramMap);
	/**
	 * 删除用户感谢信
	 * @param hashMap
	 */
	void deleteUserThanks(Map<String, Object> hashMap);
	/**
	 * 感谢信详情
	 * @param hashMap
	 * @return
	 */
	TomThanksLetterDto selectThanksLetterInfo(Map<Object, Object> hashMap);
}