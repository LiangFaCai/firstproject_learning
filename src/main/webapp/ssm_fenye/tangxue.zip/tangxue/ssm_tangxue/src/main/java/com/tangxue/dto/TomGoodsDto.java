package com.tangxue.dto;

import java.util.Date;

import com.tangxue.entity.TomCategory;
import com.tangxue.entity.TomClaimuser;
import com.tangxue.entity.TomUser;

public class TomGoodsDto {

    private Integer id;

    private String address;

    private Date crearetime;

    private Date happentime;

    private String info;

    private String mobile;

    private String name;

    private String qq;

    private String remark;

    private String result;

    private Integer state;

    private String title;

    private String typename;

    private Integer cid;

    private Integer claimuid;

    private Integer uid;
 
    private String cname;
    private TomCategory tomCategory;
    private TomClaimuser claimuser;
    private TomUser tomUser;

    
    private String email;

    private String password;

    private Integer role;

    private Integer userlock;

    private String username;

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getRole() {
		return role;
	}

	public void setRole(Integer role) {
		this.role = role;
	}

	public Integer getUserlock() {
		return userlock;
	}

	public void setUserlock(Integer userlock) {
		this.userlock = userlock;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getCrearetime() {
		return crearetime;
	}

	public void setCrearetime(Date crearetime) {
		this.crearetime = crearetime;
	}

	public Date getHappentime() {
		return happentime;
	}

	public void setHappentime(Date happentime) {
		this.happentime = happentime;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getQq() {
		return qq;
	}

	public void setQq(String qq) {
		this.qq = qq;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public Integer getState() {
		return state;
	}

	public void setState(Integer state) {
		this.state = state;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getTypename() {
		return typename;
	}

	public void setTypename(String typename) {
		this.typename = typename;
	}

	public Integer getCid() {
		return cid;
	}

	public void setCid(Integer cid) {
		this.cid = cid;
	}

	public Integer getClaimuid() {
		return claimuid;
	}

	public void setClaimuid(Integer claimuid) {
		this.claimuid = claimuid;
	}

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public String getCname() {
		return cname;
	}

	public void setCname(String cname) {
		this.cname = cname;
	}

	public TomCategory getTomCategory() {
		return tomCategory;
	}

	public void setTomCategory(TomCategory tomCategory) {
		this.tomCategory = tomCategory;
	}

	public TomUser getTomUser() {
		return tomUser;
	}

	public void setTomUser(TomUser tomUser) {
		this.tomUser = tomUser;
	}

	public TomClaimuser getClaimuser() {
		return claimuser;
	}

	public void setClaimuser(TomClaimuser claimuser) {
		this.claimuser = claimuser;
	}  
	
}
