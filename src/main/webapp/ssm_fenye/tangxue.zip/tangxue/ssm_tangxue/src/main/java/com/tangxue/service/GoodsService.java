package com.tangxue.service;

import java.util.List;
import java.util.Map;

import com.tangxue.dto.TomGoodsDto;
import com.tangxue.dto.TomReplyDto;
import com.tangxue.entity.TomClaimuser;
import com.tangxue.entity.TomGoods;
import com.tangxue.entity.TomReply;

public interface GoodsService {

	void insertPublishLost(TomGoods goods);

	List<TomGoodsDto> browsePublishLostList();

	List<TomGoodsDto> browsePublishFindList();

	List<TomGoodsDto> sucessEventList();

	TomGoodsDto selectGoodsInfoById(Integer id);

	List<TomReplyDto> selectReplyList(Integer id);

	void insertReply(TomReply reply);

	List<TomGoodsDto> globalSearchList(Map<String, Object> paramMap);

	TomGoods selectGoodsById(int id);

	TomClaimuser selectGoodsClaimuser(int id);

	void insertClaimUser(TomClaimuser claimUser);

	

	TomGoods selectManagerGoodsById(int id);

	TomClaimuser selectClaimUserByCondition(Map<Object, Object> hashMap);
	
	void updateManagerGoods(TomGoods goods);

	void deleteTomGoodsById(int id);

	List<TomReplyDto> selectManagerReplyList();

	void managerReplyDelete(int id);
}
