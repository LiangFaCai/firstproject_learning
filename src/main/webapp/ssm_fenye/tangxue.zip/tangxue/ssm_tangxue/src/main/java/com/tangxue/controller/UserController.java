package com.tangxue.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tangxue.entity.TomGoods;
import com.tangxue.entity.TomUser;
import com.tangxue.mapper.TomGoodsMapper;
import com.tangxue.service.UserService;

@Controller
public class UserController {
	
	@Autowired
	private UserService userService;
	
	@RequestMapping("/test")
	@ResponseBody
	public List getUserList() {
		
		List list=userService.getUserList();
		return list;
	}
	/**
	 * index
	 * @return
	 */
	@RequestMapping("/index")
	public String getIndex() {
		
		return "index";
	}
	/**
	 * 主页面
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/main")
	public String getMain(HttpServletRequest request,HttpServletResponse response) {
		response.setHeader("content-type","text/html;charset=UTF-8");
		List<TomGoods> lostlist = userService.selectBeanLostList();
		request.setAttribute("lostlist", lostlist);
		List<TomGoods> findlist = userService.selectBeanFindList();
		request.setAttribute("findlist", findlist);
		return "main";
	}
	/**
	 * 去登陆页面
	 */
	@RequestMapping("/tologin")
	public String toLogin() {
		return "login";
	}
	/**
	 * 登陆
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("/login")
	public void userLogin(HttpServletRequest request,HttpServletResponse response,@RequestParam String email,@RequestParam String password) throws IOException {
		response.setHeader("content-type","text/html;charset=UTF-8");
		PrintWriter writer = response.getWriter();
		TomUser user = userService.selectUser(email,password);
		if(user!=null){
			HttpSession session = request.getSession();
			session.setAttribute("user", user);			
			writer.print("<script  language='javascript'>alert('登陆成功');window.location.href='index.do'; </script>");
		}else{
			
			writer.print("<script  language='javascript'>alert('用户名或者密码错误');window.location.href='tologin.do'; </script>");
		}
	}
	
	/**
	 * 登出
	 * @throws IOException 
	 */
	@RequestMapping("/loginOut")
	public void loginOut(HttpServletRequest request,HttpServletResponse response) throws IOException {
		response.setHeader("content-type","text/html;charset=UTF-8");
		PrintWriter writer = response.getWriter();
		HttpSession session = request.getSession();
		session.removeAttribute("user");		
		writer.print("<script  language='javascript'>alert('退出成功');window.location.href='tologin.do'; </script>");
	}
	
	/**
	 * 去注册页面
	 */
	@RequestMapping("/toReg")
	public String toReg() {
		
		return "reg";
	}
	
	/**
	 * 用户注册
	 * @throws IOException 
	 */
	@RequestMapping("/reg")
	public void reg(HttpServletRequest request,HttpServletResponse response) throws IOException {
		Map<String,Object> paramMap = new HashMap<>();
		response.setHeader("content-type","text/html;charset=UTF-8");
		PrintWriter writer = response.getWriter();
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		String email = request.getParameter("email");
		TomUser user = new TomUser();
		user.setUsername(username);
		user.setPassword(password);
		user.setEmail(email);
		user.setRole(0);
		user.setUserlock(0);
		user.setCreatetime(new Date(System.currentTimeMillis()));
		paramMap.put("email", email);
		//判断账号是否已经被注册
		TomUser olduser = userService.selectByCondition(paramMap);
		if(olduser != null){
			writer.print("<script  language='javascript'>alert('邮箱已经存在!!');window.history.go(-1);</script>");	
			return;
		}
		//添加用户
		userService.inserTomUser(user);		
		writer.print("<script  language='javascript'>alert('注册成功');window.location.href='tologin.do'; </script>");
	}
	
	/**
	 * 修改密码页面
	 */
	@RequestMapping("/toUpdatePwd")
	public String updatePwd() {
		
		return "updatepsw";
	}
	
	/**
	 * 修改密码
	 * @throws IOException 
	 */
	@RequestMapping("/updatePwd")
	public void updatePwd(HttpServletRequest request,HttpServletResponse response) throws IOException {
		Map<String,Object> paramMap = new HashMap<>();
		response.setHeader("content-type","text/html;charset=UTF-8");
		PrintWriter writer = response.getWriter();
		String oldpassword = request.getParameter("oldpassword");
		String password = request.getParameter("password");
		String repassword = request.getParameter("repassword");
		if(!password.equals(repassword)){
			writer.print("<script  language='javascript'>alert('两次密码不一致!!');window.history.go(-1); </script>");
			return;
		}
		HttpSession session = request.getSession();
		TomUser user = (TomUser)session.getAttribute("user");
		if(session.getAttribute("user") == null){			
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='tologin.do'; </script>");
			return;
		}
		paramMap.put("oldpassword", oldpassword);
		paramMap.put("username", user.getUsername());
		//根据用户名和原来的密码查询
		TomUser bean = userService.selectByOldPwdAndUsername(paramMap);
		if(bean!=null){
			bean.setPassword(password);
			//更新用户密码
			userService.updateUser(bean);			
			writer.print("<script  language='javascript'>alert('success!');window.location.href='index.do'; </script>");
		}else{			
			writer.print("<script  language='javascript'>alert('原密码错误,修改失败!!');window.history.go(-1);</script>");
		}	
	}
	
}
