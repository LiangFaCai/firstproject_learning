package com.tangxue.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tangxue.dto.TomGoodsDto;
import com.tangxue.dto.TomReplyDto;
import com.tangxue.entity.TomClaimuser;
import com.tangxue.entity.TomGoods;
import com.tangxue.entity.TomReply;
import com.tangxue.mapper.TomClaimuserMapper;
import com.tangxue.mapper.TomGoodsMapper;
import com.tangxue.mapper.TomReplyMapper;
import com.tangxue.service.GoodsService;

@Service
public class GoodsServiceImpl implements GoodsService{
	
	@Autowired
	private TomGoodsMapper  tomGoodsMapper;
	@Autowired
	private TomReplyMapper tomReplyMapper;
	@Autowired
	private TomClaimuserMapper  tomClaimuserMapper;
	/**
	 * 新增发布的商品
	 */
	@Override
	public void insertPublishLost(TomGoods goods) {
		
		tomGoodsMapper.insert(goods);
	}

	/**
	 * 浏览寻物贴
	 * @return
	 */
	@Override
	public List<TomGoodsDto> browsePublishLostList() {
		
		return tomGoodsMapper.getBrowsePublishLostList();
	}
	/**
	 * 查看招领贴
	 * @return
	 */
	@Override
	public List<TomGoodsDto> browsePublishFindList() {
		
		return tomGoodsMapper.getBrowsePublishFindList();
	}

	/**
	 * 给成功案例
	 * @return
	 */
	@Override
	public List<TomGoodsDto> sucessEventList() {
		
		return tomGoodsMapper.getSucessEventList();
	}
	/**
	 * 获取物品的信息
	 */
	@Override
	public TomGoodsDto selectGoodsInfoById(Integer id) {
		
		Map<String,Object> paramMap = new HashMap<>();
		paramMap.put("id", id);
		return tomGoodsMapper.selectGoodsInfoById(paramMap);
	}

	/**
	 * 回复信息
	 */
	@Override
	public List<TomReplyDto> selectReplyList(Integer id) {
		Map<String,Object> paramMap = new HashMap<>();
		paramMap.put("id", id);
		return tomReplyMapper.selectReplyList(paramMap);
	}

	/**
	 * 添加回复
	 */
	@Override
	public void insertReply(TomReply reply) {
		
		tomReplyMapper.insert(reply);
	}

	/**
	 * 全局搜索
	 */
	@Override
	public List<TomGoodsDto> globalSearchList(Map<String, Object> paramMap) {
		
		return tomGoodsMapper.globalSearchList(paramMap);
	}
	/**
	 * 管理端物品管理获取物品信息
	 */
	@Override
	public TomGoods selectGoodsById(int id) {
		
		return tomGoodsMapper.selectByPrimaryKey(id);
	}
	/**
	 * 捡到者
	 */
	@Override
	public TomClaimuser selectGoodsClaimuser(int id) {
		Map<String,Object> paramMap = new HashMap<>();
		paramMap.put("gid", id);
		return tomClaimuserMapper.selectGoodsClaimuserByGid(paramMap);
	}
	/**
	 * 添加claimUser
	 */
	@Override
	public void insertClaimUser(TomClaimuser claimUser) {
		
		tomClaimuserMapper.insert(claimUser);
	}

	
	/**
	 * 获取管理端物品
	 */
	@Override
	public TomGoods selectManagerGoodsById(int id) {
		
		return tomGoodsMapper.selectByPrimaryKey(id);
	}
	/**
	 * 获取领取者信息
	 */
	@Override
	public TomClaimuser selectClaimUserByCondition(Map<Object, Object> hashMap) {
		
		return tomClaimuserMapper.selectClaimUserByCondition(hashMap);
	}

	/**
	 * 更新物品信息
	 */
	@Override
	public void updateManagerGoods(TomGoods goods) {
		 tomGoodsMapper.updateByPrimaryKey(goods);
	}
	/**
	 * 删除物品
	 */
	@Override
	public void deleteTomGoodsById(int id) {
		
		tomGoodsMapper.deleteByPrimaryKey(id);
	}
	/**
	 * 管理端回复管理
	 */
	@Override
	public List<TomReplyDto> selectManagerReplyList() {
		
		return tomReplyMapper.selectManagerReplyList();
	}
	/**
	 * 管理端删除回复
	 */
	@Override
	public void managerReplyDelete(int id) {
	
		tomReplyMapper.deleteByPrimaryKey(id);
	}
}
