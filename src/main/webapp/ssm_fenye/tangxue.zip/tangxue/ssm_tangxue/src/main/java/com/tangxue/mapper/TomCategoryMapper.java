package com.tangxue.mapper;

import com.tangxue.entity.TomCategory;

public interface TomCategoryMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TomCategory record);

    int insertSelective(TomCategory record);

    TomCategory selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TomCategory record);

    int updateByPrimaryKey(TomCategory record);
}