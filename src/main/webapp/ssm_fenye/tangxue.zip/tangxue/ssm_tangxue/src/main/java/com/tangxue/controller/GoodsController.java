package com.tangxue.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tangxue.dto.TomGoodsDto;
import com.tangxue.dto.TomReplyDto;
import com.tangxue.dto.TomThanksLetterDto;
import com.tangxue.entity.TomCategory;
import com.tangxue.entity.TomGoods;
import com.tangxue.entity.TomReply;
import com.tangxue.entity.TomUser;
import com.tangxue.service.GoodsService;

@Controller
public class GoodsController {
	
	@Autowired
	private GoodsService goodsService;
	
	/**
	 * 跳转发布页面
	 * @param type
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping("/publish")
	public void publishLost(@RequestParam String type,HttpServletRequest request,HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html;charset=UTF-8"); 
		HttpSession session = request.getSession();
		if(session.getAttribute("user") == null){
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='tologin.do'; </script>");
			return;
		}
		String type1 = request.getParameter("type");
		if("find".equals(type1)){
			response.sendRedirect("toPublishFind.do");
		}else{
			response.sendRedirect("toPublishlost.do");
		}
		
	}
	/**
	 *发布寻物帖
	 * @return
	 */
	@RequestMapping("/toPublishlost")
	public String toPublishLost() {
		
	    return "publishlost";
	}
	/**
	 *发布招领贴
	 * @return
	 */
	@RequestMapping("/toPublishFind")
	public String toPublishFind() {
		
	    return "publishfind";
	}
	/**
	 * 发布寻物
	 * @param request
	 * @param response
	 * @throws IOException 
	 */
	@RequestMapping("/publishLost")
	public void publishLost(HttpServletRequest request,HttpServletResponse response) throws IOException {
		response.setContentType("text/html;charset=UTF-8"); 
		HttpSession session = request.getSession();
		if(session.getAttribute("user") == null){
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='tologin.do'; </script>");
			return;
		}
		String name = request.getParameter("name");
		String title = request.getParameter("title");
		String info = request.getParameter("info");
		String remark = request.getParameter("remark");
		String mobile = request.getParameter("mobile");
		String qq = request.getParameter("qq");
		String typename = request.getParameter("type");
		//物品分类
		int cid =Integer.parseInt(request.getParameter("cid"));
		Date happentime = request.getParameter("happentime") != null&request.getParameter("happentime") != ""?java.sql.Date.valueOf(request.getParameter("happentime").toString()):new Date(System.currentTimeMillis());
		String address = request.getParameter("address");
		Date createtime = new Date(System.currentTimeMillis());
		TomUser createuser = new TomUser();
		
		createuser =(TomUser)session.getAttribute("user");
		
		TomGoods goods = new TomGoods();
		goods.setAddress(address);
		//添加分类
		goods.setCid(cid);
		goods.setCrearetime(createtime);
		goods.setHappentime(happentime);
		goods.setInfo(info);
		goods.setMobile(mobile);
		goods.setName(name);
		goods.setQq(qq);
		goods.setRemark(remark);
		/*if("find".equals(typename)) {
			goods.setState(1);
		}else {
			goods.setState(0);
		}*/
		goods.setState(0);
		goods.setTitle(title);
		goods.setTypename(typename);
		//发布者
		goods.setUid(createuser.getId());
		//发布丢失的物品
		goodsService.insertPublishLost(goods);
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='index.do'; </script>");
	}
	
	/**
	 * 浏览寻物贴
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/browsePublishLost")
	public String browsePublishLost(HttpServletRequest request,HttpServletResponse response,@RequestParam(required=true,defaultValue="1") Integer page) {
		
		response.setContentType("text/html;charset=UTF-8");
		PageHelper.startPage(page,10);
		//获取列表
		List<TomGoodsDto> list = goodsService.browsePublishLostList();
		PageInfo<TomGoodsDto> pageInfo = new PageInfo<TomGoodsDto>(list);
		request.setAttribute("pageInfo", pageInfo);
		request.setAttribute("list", list);
		return "lost";
	}
	/**
	 * 查看招领贴
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/browsePublishFind")
	public String browsePublishFind(HttpServletRequest request,HttpServletResponse response,@RequestParam(required=true,defaultValue="1") Integer page) {
		
		response.setContentType("text/html;charset=UTF-8");
		PageHelper.startPage(page,10);
		//获取列表
		List<TomGoodsDto> list = goodsService.browsePublishFindList();
		PageInfo<TomGoodsDto> pageInfo = new PageInfo<TomGoodsDto>(list);
		request.setAttribute("pageInfo", pageInfo);
		request.setAttribute("list", list);
		return "find";
	}
	
	
	/**
	 * 成功案例
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/sucessEvent")
	public String sucessEvent(HttpServletRequest request,HttpServletResponse response,@RequestParam(required=true,defaultValue="1") Integer page) {
		
		response.setContentType("text/html;charset=UTF-8");
		PageHelper.startPage(page,10);
		//获取列表
		List<TomGoodsDto> list = goodsService.sucessEventList();
		PageInfo<TomGoodsDto> pageInfo = new PageInfo<TomGoodsDto>(list);
		request.setAttribute("pageInfo", pageInfo);
		request.setAttribute("list", list);
		return "success";
	}
	/**
	 * 物品的失物招物信息
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/goodsInfoBrowse")
	public String goodsInfoBrowse(HttpServletRequest request,HttpServletResponse response,@RequestParam("id") Integer id) {
		
		TomGoodsDto goods = goodsService.selectGoodsInfoById(id);
		request.setAttribute("goods", goods);
		//评论
		List<TomReplyDto> replylist = goodsService.selectReplyList(id);
		request.setAttribute("replylist", replylist);	
		//是否登陆
		int islogin = IsLogin(request,response);
		request.setAttribute("islogin", islogin);	
		return "view";
	}
	
	/**
	 * 判断条件
	 * @param request
	 * @param response 
	 * @return
	 */
	public int IsLogin(HttpServletRequest request, HttpServletResponse response) {
		
		TomUser user = ((TomUser) request.getSession().getAttribute("user")); 
		if(user == null){
			return 0;
		}
		return 1;
	}
	
	/**
	 * 评论提交
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("/replySubmit")
	public void replySubmit(HttpServletRequest request,HttpServletResponse response) throws IOException {
		
		response.setContentType("text/html;charset=UTF-8"); 
		HttpSession session = request.getSession();
		PrintWriter writer = response.getWriter();
		if(session.getAttribute("user") == null){
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='tologin.do'; </script>");
			return;
		}
		int gid = Integer.parseInt(request.getParameter("gid"));
		String content = request.getParameter("content");
		TomUser user = new TomUser();
		user = (TomUser)request.getSession().getAttribute("user");
		Date createtime = new Date(System.currentTimeMillis());
		
		TomReply reply = new TomReply();
		reply.setContent(content);
		reply.setCreatetime(createtime);
		reply.setGid(gid);
		reply.setUid(user.getId());
		
		goodsService.insertReply(reply);
		
		writer.print("<script  language='javascript'>alert('success!');window.location.href='goodsInfoBrowse.do?id="+gid+"'; </script>");
		
	}
	

	
	/**
	 * 全局搜搜
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("/globalSearch")
	public String globalSearch(HttpServletRequest request,HttpServletResponse response,@RequestParam(required=true,defaultValue="1") Integer page) throws UnsupportedEncodingException {
		
		Map<String,Object> paramMap = new HashMap<>();
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		PageHelper.startPage(page,10);
		//查询条件
		//关键词
		String key = request.getParameter("key");
		//物品种类
		int catid = 0;
		if(request.getParameter("catid") != null){
			catid = Integer.parseInt(request.getParameter("catid"));
		}
	    //事件类型
		String typename = request.getParameter("type");
		//地点
		String address = request.getParameter("address");
		String starttime = request.getParameter("starttime");
		String endtime = request.getParameter("endtime");
		//存值
		paramMap.put("key",key);
		paramMap.put("catid",catid);
		paramMap.put("typename",typename);
		paramMap.put("address",address);
		paramMap.put("starttime",starttime);
		paramMap.put("endtime",endtime);
		//获取列表
		List<TomGoodsDto> list = goodsService.globalSearchList(paramMap);
		PageInfo<TomGoodsDto> pageInfo = new PageInfo<TomGoodsDto>(list);
		request.setAttribute("pageInfo", pageInfo);
		request.setAttribute("list", list);
		//查询条件
		request.setAttribute("key", key);
		request.setAttribute("type", typename);
		request.setAttribute("address", address);
		request.setAttribute("starttime", starttime);
		request.setAttribute("endtime", endtime);
		request.setAttribute("key", key);
		//分类id
		request.setAttribute("catid", catid);
		request.setAttribute("size", list.size());
		return "search";
	}
	
	
	
	
	
	
	
}
