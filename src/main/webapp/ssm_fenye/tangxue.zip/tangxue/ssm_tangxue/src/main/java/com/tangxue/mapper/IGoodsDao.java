package com.tangxue.mapper;

import java.util.List;
import java.util.Map;

import com.tangxue.entity.Goods;

public interface IGoodsDao {

	List<Goods> queryAll();

	List<Goods> queryGoodsBySql(Map<String, Object> data);

}
