package com.tangxue.service;

import java.util.List;
import java.util.Map;

import com.tangxue.entity.TomGoods;
import com.tangxue.entity.TomUser;

public interface UserService {

	List getUserList();

	List<TomGoods> selectBeanLostList();

	List<TomGoods> selectBeanFindList();

	TomUser selectUser(String email, String password);

	TomUser selectByCondition(Map<String, Object> paramMap);

	void inserTomUser(TomUser user);

	TomUser selectByOldPwdAndUsername(Map<String, Object> paramMap);

	void updateUser(TomUser bean);	
}
