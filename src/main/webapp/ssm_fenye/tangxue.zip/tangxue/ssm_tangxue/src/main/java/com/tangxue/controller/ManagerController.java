package com.tangxue.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tangxue.dto.TomGoodsDto;
import com.tangxue.dto.TomReplyDto;
import com.tangxue.dto.TomThanksLetterDto;
import com.tangxue.entity.TomClaimuser;
import com.tangxue.entity.TomGoods;
import com.tangxue.entity.TomReply;
import com.tangxue.entity.TomThanksLetter;
import com.tangxue.entity.TomUser;
import com.tangxue.service.GoodsService;
import com.tangxue.service.ManagerService;
import com.tangxue.service.ThanksService;

@Controller
public class ManagerController {
	
	@Autowired
	private ManagerService managerService;
	@Autowired
	private GoodsService goodsService;
	@Autowired
	private ThanksService thanksService;
	/**
	 * 进入登陆界面
	 * @return
	 */
	@RequestMapping("/toManagerLogin")
	public String manager() {
		
		return "/admin/login";
	}
	
	/**
	 * 管理端index
	 * @return
	 */
	@RequestMapping("/managerIndex")
	public String managerIndex() {
		
		return "/admin/index";
	}
	
	/**
	 * 进入主界面
	 * @return
	 */
	@RequestMapping("/toManagerMain")
	public String toManagerMain() {
		
		return "/admin/main";
	}
	
	/**
	 * 管理端登陆
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping("/managerLogin")
	public void managerLogin(HttpServletRequest request,HttpServletResponse response) throws IOException{
		response.setHeader("content-type","text/html;charset=UTF-8");
		PrintWriter writer = response.getWriter();
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		Map<String,Object> paramMap = new HashMap<>();
		paramMap.put("email", email);
		paramMap.put("password", password);
		TomUser user=managerService.selectManagerUser(paramMap);
		if(user!=null){
			HttpSession session = request.getSession();
			session.setAttribute("admin", user);
			writer.print("<script  language='javascript'>alert('success!');window.location.href='managerIndex.do'; </script>");
		}else{
			
			writer.print("<script  language='javascript'>alert('用户名或者密码错误,或你不是管理员');window.location.href='toManagerLogin.do'; </script>");
		}
	}

	/**
	 * 管理端登出页面
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping("/managerLoginOut")
	public void managerLoginOut(HttpServletRequest request,HttpServletResponse response) throws IOException{
		response.setHeader("content-type","text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		HttpSession session = request.getSession();
		session.removeAttribute("admin");
		response.setCharacterEncoding("utf-8");
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('退出成功');window.location.href='toManagerLogin.do'; </script>");
	}

	/**
	 * 去管理端更新密码页面
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("/toManagerUpdatePwd")
	public String toManagerUpdatePwd(HttpServletRequest request,HttpServletResponse response) throws IOException {
		response.setHeader("content-type","text/html;charset=UTF-8");
		HttpSession session = request.getSession();
		if(session.getAttribute("admin") == null){
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='login.jsp'; </script>");
		}
		return "/admin/user/updatepwd";
		
	}
	/**
	 * 管理端密码修改
	 * @param request
	 * @param response
	 * @throws IOException 
	 */
	@RequestMapping("/managerUpdatePwd")
	public void managerUpdatePwd(HttpServletRequest request,HttpServletResponse response) throws IOException {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		response.setHeader("content-type","text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		PrintWriter writer = response.getWriter();
		HttpSession session = request.getSession();
		if(session.getAttribute("admin") == null){
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='toManagerLogin.do'; </script>");
			return ;
		}
		String oldpassword = request.getParameter("oldpassword");
		String password = request.getParameter("password");
		String repassword = request.getParameter("repassword");
		if(!password.equals(repassword)){
			writer.print("<script  language='javascript'>alert('两次密码不一致!!');window.history.go(-1); </script>");
			return;
		}
		TomUser user = (TomUser)session.getAttribute("admin");
		paramMap.put("email",user.getEmail());
		paramMap.put("oldpassword",oldpassword);
		//获取原对象
		TomUser bean = managerService.selectOldUser(paramMap);
		if(bean!=null){
			bean.setPassword(password);
			managerService.updateUserPwd(bean);			
			writer.print("<script  language='javascript'>alert('success!');window.location.href='toManagerMain.do'; </script>");
		}else{			
			writer.print("<script  language='javascript'>alert('原密码错误,修改失败!!');window.history.go(-1);</script>");
		}	
	}
	
	/**
	 * 管理端用户列表
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("/toManagerUserList")
	public String managerUserList(HttpServletRequest request,HttpServletResponse response,@RequestParam(required=true,defaultValue="1") Integer page) throws IOException {
		Map<String,Object> paramMap = new HashMap<String,Object>();
		response.setHeader("content-type","text/html;charset=UTF-8");
		PrintWriter writer = response.getWriter();
		HttpSession session = request.getSession();
		if(session.getAttribute("admin") == null){
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='toManagerLogin.do'; </script>");
		}
		//分页
		PageHelper.startPage(page,10);
		String email = request.getParameter("email");
		String rolep = request.getParameter("role");
		int role=-1;
		if(rolep!=null && !"".equals(rolep)) {
			role = Integer.parseInt(rolep);
		}
		paramMap.put("email", email);
		paramMap.put("role", role);
		//获取列表
		List<TomUser> list = managerService.managerUserList(paramMap);
		PageInfo<TomUser> pageInfo = new PageInfo<TomUser>(list);
		request.setAttribute("pageInfo", pageInfo);
		request.setAttribute("list", list);
		request.setAttribute("email", email);
		request.setAttribute("role", role);
		
		return "/admin/user/userlist";
	}
	/**
	 * 去添加用户界面
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("/toAddManagerUser")
	public String toAddManagerUser(HttpServletRequest request,HttpServletResponse response) throws IOException {
		response.setHeader("content-type","text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		PrintWriter writer = response.getWriter();
		HttpSession session = request.getSession();
		if(session.getAttribute("admin") == null){
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='toManagerLogin.do'; </script>");
		}
		return "/admin/user/useradd";
	}
	
	/**
	 * 管理端用户添加
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping("/addManagerUser")
	public void addManagerUser(HttpServletRequest request,HttpServletResponse response) throws IOException{
		Map<String,Object> paramMap = new HashMap<String,Object>();
		response.setHeader("content-type","text/html;charset=UTF-8");
		PrintWriter writer = response.getWriter();
		
		HttpSession session = request.getSession();
		if(session.getAttribute("admin") == null){
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='toManagerLogin.do'; </script>");
			return;
		}
		String username = request.getParameter("username");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		int role = Integer.parseInt(request.getParameter("role"));
		int id = request.getParameter("id")==null || request.getParameter("id")=="" ?0:Integer.parseInt(request.getParameter("id"));
		paramMap.put("email", email);
		paramMap.put("username", username);
		TomUser bean = managerService.selectUserByConditions(paramMap);
		if(id == 0 && bean != null){			
			writer.print("<script  language='javascript'>alert('邮箱已经存在或者用户名已经存在!!');window.history.go(-1);</script>");	
			return;
		}
		bean = new TomUser();
		bean.setUsername(username);
		bean.setEmail(email);
		bean.setRole(role);
		bean.setCreatetime(new Date(System.currentTimeMillis()));
		bean.setPassword(password);	
		bean.setUserlock(0);
		if(id==0){
			managerService.insertManagerUser(bean);
		}else{
			bean.setId(id);
			managerService.updateManagerUser(bean);
		}
		response.setCharacterEncoding("utf-8");
		writer.print("<script  language='javascript'>alert('success!');window.location.href='toManagerUserList.do'; </script>");		
	}
	
	/**
	 * 跳转到编辑用户页面
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/toEditManagerUser")
	public String toEditManagerUser(HttpServletRequest request,HttpServletResponse response) throws IOException{
		response.setHeader("content-type","text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		PrintWriter writer = response.getWriter();
		HttpSession session = request.getSession();
		if(session.getAttribute("admin") == null){
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='toManagerLogin.do'; </script>");
		}
		int id =Integer.parseInt(request.getParameter("id"));
		TomUser user = managerService.selectManagerUserById(id);
		request.setAttribute("user", user);
		return "/admin/user/userview";
	}
	/**
	 * 管理端用户删除
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping("/managerDeleteUser")
	public void managerDeleteUser(HttpServletRequest request,HttpServletResponse response) throws IOException{
		Map<String,Object> paramMap = new HashMap<String,Object>();
		response.setContentType("text/html;charset=UTF-8");
		PrintWriter writer = response.getWriter();
		HttpSession session = request.getSession();
		if(session.getAttribute("admin") == null){
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='toManagerLogin.do'; </script>");
			return;
		}
		int id = request.getParameter("id")==null?0:Integer.parseInt(request.getParameter("id"));
		paramMap.put("uid", id);
		//用户物品
		List<TomGoods> goodslist = managerService.selectUserGoodsById(paramMap);
		if(goodslist!=null && goodslist.size()>0) {
			for(int i =0; i < goodslist.size(); i++){			
				managerService.deleteUserGoods(goodslist.get(i));
			}
		}
		//用户回复
		List<TomReply> replylist = managerService.selectUserReplyList(paramMap);
		if(replylist!=null && replylist.size()>0) {
			for(int i =0; i < replylist.size(); i++){			
				managerService.deleteUserReply(replylist.get(i));
			}
		}
		//用户感谢信
		List<TomThanksLetter> thankslist = managerService.selectThanksList(paramMap);
		if(thankslist!=null && thankslist.size()>0) {
			for(int i =0; i < thankslist.size(); i++){			
				managerService.deleteUserThanks(thankslist.get(i));
			}
		}
		//删除用户
		managerService.deleteUserById(id);
		writer.print("<script  language='javascript'>alert('success!');window.location.href='toManagerUserList.do'; </script>");
	}
	

	/**
	 * 进入物品管理页面
	 * @return
	 * @throws UnsupportedEncodingException 
	 */
	@RequestMapping("/toManagerGoods")
	public String toManagerGoods(HttpServletRequest request,HttpServletResponse response,@RequestParam(required=true,defaultValue="1") Integer page) throws UnsupportedEncodingException {
		Map<String,Object> paramMap = new HashMap<>();
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		PageHelper.startPage(page,10);
		//查询条件
		//关键词
		String key = request.getParameter("key");
		//物品种类
		int catid = 0;
		if(request.getParameter("catid") != null){
			catid = Integer.parseInt(request.getParameter("catid"));
		}
	    //事件类型
		String typename = request.getParameter("type");
		//地点
		String address = request.getParameter("address");
		String starttime = request.getParameter("starttime");
		String endtime = request.getParameter("endtime");
		//存值
		paramMap.put("key",key);
		paramMap.put("catid",catid);
		paramMap.put("typename",typename);
		paramMap.put("address",address);
		paramMap.put("starttime",starttime);
		paramMap.put("endtime",endtime);
		//获取列表
		List<TomGoodsDto> list = goodsService.globalSearchList(paramMap);
		PageInfo<TomGoodsDto> pageInfo = new PageInfo<TomGoodsDto>(list);
		request.setAttribute("pageInfo", pageInfo);
		request.setAttribute("list", list);
		//查询条件
		request.setAttribute("key", key);
		request.setAttribute("type", typename);
		request.setAttribute("address", address);
		request.setAttribute("starttime", starttime);
		request.setAttribute("endtime", endtime);
		request.setAttribute("key", key);
		//分类id
		request.setAttribute("catid", catid);
		request.setAttribute("size", list.size());
		return "/admin/goods/goodslist";
	}
	
	
	
	/**
	 * 进入物品管理编辑页面
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("/toManagerGoodsEdit")
	public String toManagerGoodsEdit(HttpServletRequest request,HttpServletResponse response) throws IOException {
		Map<String,Object> paramMap = new HashMap<>();
		response.setContentType("text/html;charset=UTF-8");
		request.setCharacterEncoding("utf-8");
		
		HttpSession session = request.getSession();
		if(session.getAttribute("admin") == null){
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='toManagerUserList.do'; </script>");
		}
		int id =Integer.parseInt(request.getParameter("id"));
		TomGoodsDto goods = goodsService.selectGoodsInfoById(id);
		//捡到者的联系
		TomClaimuser claimuser=goodsService.selectGoodsClaimuser(id);
		goods.setClaimuser(claimuser);
		request.setAttribute("goods", goods);
		return "/admin/goods/goodsedit";
	}
	
	/**
	 * 管理端物品修改
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping("/managerGoodsEdit")
	public void managerGoodsEdit(HttpServletRequest request,HttpServletResponse response) throws IOException{
		response.setContentType("text/html;charset=UTF-8"); 
		HttpSession session = request.getSession();
		if(session.getAttribute("admin") == null){
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='toManagerUserList.do'; </script>");
			return;
		}
		int id =Integer.parseInt(request.getParameter("id"));
		String name = request.getParameter("name");
		String title = request.getParameter("title");
		String info = request.getParameter("info");
		String remark = request.getParameter("remark");
		String mobile = request.getParameter("mobile");
		String qq = request.getParameter("qq");
		String result = request.getParameter("result");
		int state =Integer.parseInt(request.getParameter("state"));
		
		int cid =Integer.parseInt(request.getParameter("cid"));
		//获取对象
		TomGoods goods = goodsService.selectManagerGoodsById(id);
	
		Date happentime = java.sql.Date.valueOf(request.getParameter("happentime").toString());
		String address = request.getParameter("address");
		Date createtime = new Date(System.currentTimeMillis());
		goods.setAddress(address);
		goods.setCid(cid);
		goods.setCrearetime(createtime);
		goods.setHappentime(happentime);
		goods.setInfo(info);
		goods.setMobile(mobile);
		goods.setName(name);
		goods.setQq(qq);
		goods.setRemark(remark);
		goods.setState(state);
		goods.setTitle(title);
		goods.setResult(result);
		if(state == 1){
			String username = request.getParameter("username");
			String email = request.getParameter("email");
			String tel = request.getParameter("tel");
			TomClaimuser claimUser = new TomClaimuser();
			claimUser.setEmail(email);
			claimUser.setTel(tel);
			claimUser.setUsername(username);
			goodsService.insertClaimUser(claimUser);
			Map<Object,Object> hashMap = new HashMap<>();
			hashMap.put("username", username);
			hashMap.put("email", email);
			hashMap.put("tel", tel);
			TomClaimuser newClaimUser=goodsService.selectClaimUserByCondition(hashMap);
			goods.setClaimuid(newClaimUser.getId());
		}
		//更新物品信息
		goodsService.updateManagerGoods(goods);
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='toManagerGoods.do'; </script>");
	}

	/**
	 * 管理端删除物品
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping("/managerGoodsdelete")
	public void managerGoodsdelete(HttpServletRequest request,HttpServletResponse response) throws IOException{
		response.setContentType("text/html;charset=UTF-8"); 
		PrintWriter writer = response.getWriter();
		HttpSession session = request.getSession();
		if(session.getAttribute("admin") == null){
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='toManagerLogin.do'; </script>");
			return;
		}
		int id = request.getParameter("id")==null?0:Integer.parseInt(request.getParameter("id"));
		goodsService.deleteTomGoodsById(id);		
		writer.print("<script  language='javascript'>alert('success!');window.location.href='toManagerGoods.do'; </script>");
	}
	

	
	/**
	 * 进入感谢信管理页面
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("/toManagerThanks")
	public String toManagerThanks(HttpServletRequest request,HttpServletResponse response,@RequestParam(required=true,defaultValue="1") Integer page) throws IOException {
		response.setContentType("text/html;charset=UTF-8"); 
		PrintWriter writer = response.getWriter();
		HttpSession session = request.getSession();
		if(session.getAttribute("admin") == null){
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='toManagerLogin.do'; </script>");
		}
		PageHelper.startPage(page,10);
		//获取列表
		List<TomThanksLetterDto> list = thanksService.selectThanksLetterList();
		PageInfo<TomThanksLetterDto> pageInfo = new PageInfo<TomThanksLetterDto>(list);
		request.setAttribute("pageInfo", pageInfo);
		request.setAttribute("list", list);
		return "/admin/thanks/thankslist";
	}
	/**
	 * 管理端感谢信删除
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping("/managerThanksDelete")
	public void managerThanksDelete(HttpServletRequest request,HttpServletResponse response) throws IOException{
		response.setContentType("text/html;charset=UTF-8"); 
		PrintWriter writer = response.getWriter();
		
		HttpSession session = request.getSession();
		if(session.getAttribute("admin") == null){
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='toManagerLogin.do'; </script>");
			return;
		}
		int id = request.getParameter("id")==null?0:Integer.parseInt(request.getParameter("id"));
		thanksService.managerThanksDelete(id);
		writer.print("<script  language='javascript'>alert('success!');window.location.href='toManagerThanks.do'; </script>");
	}
	
	
	
	/**
	 * 进入评论管理页面
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("/toManagerReply")
	public String toManagerReply(HttpServletRequest request,HttpServletResponse response,@RequestParam(required=true,defaultValue="1") Integer page) throws IOException {
		response.setContentType("text/html;charset=UTF-8"); 
		HttpSession session = request.getSession();
		PrintWriter writer = response.getWriter();
		if(session.getAttribute("admin") == null){
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='toManagerLogin.do'; </script>");
		}
		PageHelper.startPage(page,10);
		//获取列表
		List<TomReplyDto> list = goodsService.selectManagerReplyList();
		PageInfo<TomReplyDto> pageInfo = new PageInfo<TomReplyDto>(list);
		request.setAttribute("pageInfo", pageInfo);
		request.setAttribute("list", list);
		
		return "/admin/reply/replylist";
	}
	/**
	 * 评论删除
	 * @param request
	 * @param response
	 * @throws IOException
	 */
	@RequestMapping("/managerReplyDelete")
	public void managerReplyDelete(HttpServletRequest request,HttpServletResponse response) throws IOException{
		response.setContentType("text/html;charset=UTF-8"); 
		PrintWriter writer = response.getWriter();
		HttpSession session = request.getSession();
		if(session.getAttribute("admin") == null){
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='toManagerLogin.do'; </script>");
			return;
		}
		int id = request.getParameter("id")==null?0:Integer.parseInt(request.getParameter("id"));
		goodsService.managerReplyDelete(id);
		writer.print("<script  language='javascript'>alert('success!');window.location.href='toManagerReply.do'; </script>");
	}
	
}
