package com.tangxue.service;

import java.util.List;

import com.tangxue.dto.TomThanksLetterDto;
import com.tangxue.entity.TomThanksLetter;

public interface ThanksService{

	void insertThanksLetter(TomThanksLetter thanks);

	long selectThaknksCount();

	List<TomThanksLetterDto> selectThanksLetterList();

	TomThanksLetterDto selectThanksLetterInfo(String id);

	void managerThanksDelete(int id);

}
