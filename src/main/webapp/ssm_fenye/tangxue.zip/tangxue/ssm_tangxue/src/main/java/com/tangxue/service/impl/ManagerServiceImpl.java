package com.tangxue.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tangxue.dto.TomGoodsDto;
import com.tangxue.entity.TomGoods;
import com.tangxue.entity.TomReply;
import com.tangxue.entity.TomThanksLetter;
import com.tangxue.entity.TomUser;
import com.tangxue.mapper.TomGoodsMapper;
import com.tangxue.mapper.TomReplyMapper;
import com.tangxue.mapper.TomThanksLetterMapper;
import com.tangxue.mapper.TomUserMapper;
import com.tangxue.service.ManagerService;


@Service
public class ManagerServiceImpl implements ManagerService{

	@Autowired
	private TomUserMapper tomUserMapper;
	
	@Autowired
	private TomGoodsMapper tomGoodsMapper;
	
	@Autowired
	private TomReplyMapper tomReplyMapper;

	@Autowired
	private TomThanksLetterMapper tomThanksLetterMapper;
	/**
	 * 管理端登陆
	 */
	@Override
	public TomUser selectManagerUser(Map<String, Object> paramMap) {
		
		return tomUserMapper.selectManagerUser(paramMap);
	}
	/**
	 * 获取原来的对象
	 */
	@Override
	public TomUser selectOldUser(Map<String, Object> paramMap) {
		
		return tomUserMapper.selectUserByOldPwdAndEmail(paramMap);
	}
	/**
	 * 更新密码
	 */
	@Override
	public void updateUserPwd(TomUser bean) {
		
		tomUserMapper.updateByPrimaryKey(bean);
	}
	/**
	 * 管理端用户列表查询
	 */
	@Override
	public List<TomUser> managerUserList(Map<String, Object> paramMap) {
	
		return tomUserMapper.selectManagerUserList(paramMap);
	}
	
	/**
	 * 管理端添加时判断是否已经存在用户
	 */
	@Override
	public TomUser selectUserByConditions(Map<String, Object> paramMap) {
	
		return tomUserMapper.selectUserByConditions(paramMap);
	}
	/**
	 * 管理端新增用户
	 */
	@Override
	public void insertManagerUser(TomUser bean) {
		
		tomUserMapper.insert(bean);
	}
	/**
	 * 管理端修改用户
	 */
	@Override
	public void updateManagerUser(TomUser bean) {
		
		tomUserMapper.updateByPrimaryKey(bean);
	}
	/**
	 * 跳转到修改用户界面
	 */
	@Override
	public TomUser selectManagerUserById(int id) {
		
		return tomUserMapper.selectByPrimaryKey(id);
	}
	/**
	 * 获取用户物品
	 */
	@Override
	public List<TomGoods> selectUserGoodsById(Map<String, Object> paramMap) {

		return tomGoodsMapper.selectUserGoodsById(paramMap);
	}
	/**
	 * 删除用户物品
	 */
	@Override
	public void deleteUserGoods(TomGoods tomGoods) {
		Map<String,Object> hashMap = new HashMap<>();
		hashMap.put("uid", tomGoods.getUid());
		tomGoodsMapper.deleteUserGoods(hashMap);
	}
	/**
	 * 获取用户回复
	 */
	@Override
	public List<TomReply> selectUserReplyList(Map<String, Object> paramMap) {
		
		return tomReplyMapper.selectUserReplyList(paramMap);
	}
	/**
	 * 删除用户回复
	 */
	@Override
	public void deleteUserReply(TomReply tomReply) {
		Map<String,Object> hashMap = new HashMap<>();
		hashMap.put("uid", tomReply.getUid());
		tomReplyMapper.deleteUserReply(hashMap);
	}
	/**
	 * 根据用户id获取感谢信列表
	 */
	@Override
	public List<TomThanksLetter> selectThanksList(Map<String, Object> paramMap) {
		
		return tomThanksLetterMapper.selectThanksList(paramMap);
	}
	/**
	 * 删除用户感谢信
	 */
	@Override
	public void deleteUserThanks(TomThanksLetter tomThanksLetter) {
		Map<String,Object> hashMap = new HashMap<>();
		hashMap.put("uid", tomThanksLetter.getUid());
		tomThanksLetterMapper.deleteUserThanks(hashMap);
	}
	/**
	 * 管理端删除用户
	 */
	@Override
	public void deleteUserById(int id) {
		tomUserMapper.deleteByPrimaryKey(id);
	}
	
	
}
