package com.tangxue.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tangxue.entity.Goods;
import com.tangxue.mapper.IGoodsDao;
import com.tangxue.service.IGoodsService;
@Service
public class IGoodsServiceImpl implements IGoodsService{

	@Autowired
	private IGoodsDao goodsDao;
 
	public List<Goods> queryAll() {
		return goodsDao.queryAll();
	}

	@Override
	public List<Goods> queryGoodsBySql(int currPage, int pageSize) {
		    Map<String, Object> data = new HashMap();
	        data.put("currIndex", (currPage-1)*pageSize);
	        data.put("pageSize", pageSize);
	        return goodsDao.queryGoodsBySql(data);
	}

}
