package com.tangxue.dto;

import java.util.Date;

import com.tangxue.entity.TomUser;

public class TomThanksLetterDto {

    private Integer id;

    private Date crearetime;

    private String info;

    private String title;

    private Integer uid;
 
    //用户
    private Date createtime;

    private String email;

    private String password;

    private Integer role;

    private Integer userlock;

    private String username;
    
    
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public Date getCrearetime() {
		return crearetime;
	}

	public void setCrearetime(Date crearetime) {
		this.crearetime = crearetime;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Integer getUid() {
		return uid;
	}

	public void setUid(Integer uid) {
		this.uid = uid;
	}

	public Date getCreatetime() {
		return createtime;
	}

	public void setCreatetime(Date createtime) {
		this.createtime = createtime;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Integer getRole() {
		return role;
	}

	public void setRole(Integer role) {
		this.role = role;
	}

	public Integer getUserlock() {
		return userlock;
	}

	public void setUserlock(Integer userlock) {
		this.userlock = userlock;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

}
