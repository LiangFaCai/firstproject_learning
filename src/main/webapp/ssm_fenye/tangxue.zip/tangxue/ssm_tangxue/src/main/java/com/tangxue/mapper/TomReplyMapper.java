package com.tangxue.mapper;

import java.util.List;
import java.util.Map;

import com.tangxue.dto.TomReplyDto;
import com.tangxue.entity.TomReply;

public interface TomReplyMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(TomReply record);

    int insertSelective(TomReply record);

    TomReply selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(TomReply record);

    int updateByPrimaryKey(TomReply record);
    /**
     * 根物品id获取回复
     * @param paramMap
     * @return
     */
	List<TomReplyDto> selectReplyList(Map<String, Object> paramMap);
	/**
	 * 根据用户id获取回复列表
	 * @param paramMap
	 * @return
	 */
	List<TomReply> selectUserReplyList(Map<String, Object> paramMap);
	/**
	 * 根据用户id删除回复列表
	 * @param hashMap
	 */
	void deleteUserReply(Map<String, Object> hashMap);
	/**
	 * 管理端回复管理
	 * @return
	 */
	List<TomReplyDto> selectManagerReplyList();
}