package com.tangxue.util;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.tangxue.entity.TomUser;
import com.tangxue.mapper.TomUserMapper;



public class Util {
		
	@Autowired
	private TomUserMapper tomUserMapper;

	//初始化系�?
	public void init(HttpServletRequest request){
	    TomUser user = tomUserMapper.selectBean();
  		if(user==null){
  			user = new TomUser();
  			user.setPassword("111111");
  			user.setRole(1);
  			user.setEmail("admin@qq.com");
  			user.setUsername("admin");
  			tomUserMapper.insert(user);
  		}
	}
	
}
