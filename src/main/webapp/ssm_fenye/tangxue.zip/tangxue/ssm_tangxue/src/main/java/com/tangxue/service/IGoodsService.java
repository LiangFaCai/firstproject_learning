package com.tangxue.service;

import java.util.List;

import com.tangxue.entity.Goods;

public interface IGoodsService {

	List<Goods> queryAll();
	
	List<Goods> queryGoodsBySql(int currPage, int pageSize);

}
