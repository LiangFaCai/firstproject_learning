package com.tangxue.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.tangxue.dto.TomThanksLetterDto;
import com.tangxue.entity.TomThanksLetter;
import com.tangxue.entity.TomUser;
import com.tangxue.service.ThanksService;

@Controller
public class ThanksWriteController {

	@Autowired
	private ThanksService thanksService;
	
	/**
	 * 去写感谢信
	 * @return
	 * @throws IOException 
	 */
	@RequestMapping("/toWriteThanks.do")
	public void toThanksWrite(HttpServletRequest request,HttpServletResponse response) throws IOException {
		response.setContentType("text/html;charset=UTF-8"); 
		HttpSession session = request.getSession();
		if(session.getAttribute("user") == null){
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='tologin.do'; </script>");
		}else {
			response.sendRedirect("writeThanks.do");
		}
	}
	/**
	 * 写感谢信页面
	 * @return
	 */
	@RequestMapping("/writeThanks")
	public String writeThanks() {
		
		return "write";
	}
	
	/**
	 * 感谢信提交
	 * @throws IOException 
	 */
	@RequestMapping("/thanksWrite")
	public void thanksWrite(HttpServletRequest request,HttpServletResponse response) throws IOException {
		response.setContentType("text/html;charset=UTF-8"); 
		HttpSession session = request.getSession();
		if(session.getAttribute("user") == null){
			PrintWriter writer = response.getWriter();
			writer.print("<script  language='javascript'>alert('请先登录');window.location.href='tologin.do'; </script>");
			return;
		}
		String info = request.getParameter("info");
		String title = request.getParameter("title");
		
		TomUser user = new TomUser();
		user = (TomUser)request.getSession().getAttribute("user");
		Date createtime = new Date(System.currentTimeMillis());
		
		TomThanksLetter thanks = new TomThanksLetter();
		thanks.setTitle(title);
		thanks.setInfo(info);
		thanks.setUid(user.getId());
		thanks.setCrearetime(createtime);
		thanksService.insertThanksLetter(thanks);
		PrintWriter writer = response.getWriter();
		writer.print("<script  language='javascript'>alert('success!');window.location.href='thanksLetterList.do'; </script>");		
	}
	/**
	 * 保存感谢信的列表
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/thanksLetterList")
	public String thanksLetterList(HttpServletRequest request,HttpServletResponse response,@RequestParam(required=true,defaultValue="1") Integer page) throws IOException{
		
		PageHelper.startPage(page,10);
		//获取列表
		List<TomThanksLetterDto> list = thanksService.selectThanksLetterList();
		PageInfo<TomThanksLetterDto> pageInfo = new PageInfo<TomThanksLetterDto>(list);
		request.setAttribute("pageInfo", pageInfo);
		request.setAttribute("list", list);
		return "thanks";
	}
	
	
	/**
	 * 感谢信view
	 * @param request
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/thanksLetterInfo")
	public String thanksLetterInfo(HttpServletRequest request,HttpServletResponse response) throws IOException{
		//获取列表
		String id = request.getParameter("id");
		TomThanksLetterDto thanks = thanksService.selectThanksLetterInfo(id);
		request.setAttribute("thanks", thanks);
		return "thanksview";
	}
	
}
